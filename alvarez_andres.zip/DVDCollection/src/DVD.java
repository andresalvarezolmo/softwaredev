/**
 * Stores information and methods about the DVDs of the collection.
 * 
 * @author Andres Alvarez 
 * @version 1.0
 */

import java.util.Scanner;

public class DVD {
	//creates fields title, directorName, runningTime and purchaseCost for the class
		private String title;
		private String directorName;
		private int runningTime;
		private int purchaseCost;
		
		
		/**
	     * Constructor for objects of class DVD
	     * Set default values for all fields
	     */		
	public DVD () {
		directorName = " ";
		runningTime = 0;
		purchaseCost = 0;
		
	}/**
	 * display the fields with the information about the DVDs
	 */
	
	public void display () {
		System.out.println("");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("These are the DVD details you entered");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Title: " + title);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Director: " + directorName);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Run time: " + runningTime + " minutes");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Cost: " + purchaseCost + " pounds");
		System.out.println("");
		System.out.println("--------------------------------------");
		System.out.println("");

	}
		
	/**
	 * generate a constructor using fields
	 */
		
	public DVD(String title, String directorName, int runningTime, int purchaseCost) {
		super();
		this.title = title;
		this.directorName = directorName;
		this.runningTime = runningTime;
		this.purchaseCost = purchaseCost;
	}

	
	 /**
     * Set all fields for the DVD
     */
	public void setAll() {
		Scanner s1 = new Scanner(System.in);
				
				// user is asked for the title of the film
				System.out.println("What is the title of the DVD? ");
				title = s1.nextLine();
		
		
				// user is asked for the director of the film
				System.out.println("What is the director of the DVD? ");
				directorName = s1.nextLine();
				
				// user is asked for run time of the DVD in minutes
				System.out.println("What is the duration of the DVD? (use minutes) ");
				runningTime = s1.nextInt();
				
				// user is asked for the price of the DVD
				System.out.println("What is the price of the DVD (use pounds)? ");
				purchaseCost = s1.nextInt();
			
	}
	
	// getter for title
	public String getTitle() {
		return title;
	}
	
	// setter for title
	public void setTitle(String title) {
		this.title = title;
	}
	
	// getter for directorName
	public String getdirectorName() {
			return directorName;
		}

	// setter for directorName
	public void setdirectorName(String directorName) {
			this.directorName = directorName;
		}

	// getter for runningTime
		public int getRunningTime() {
			return runningTime;
		}
		
	// setter for runningTime
		public void setRunningTime(int runningTime) {
			this.runningTime = runningTime;
		}

	// getter for purchaseCost
		public int getPurchaseCost() {
			return purchaseCost;
		}

	// setter for purchaseCost
		public void setPurchaseCost(int purchaseCost) {
			this.purchaseCost = purchaseCost;
		}
	
}
