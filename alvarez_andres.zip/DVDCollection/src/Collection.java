/**
 * Stores information and methods about the DVDs of the collection and contains the main method
 * 
 * @author Andres Alvarez 
 * @version 1.0
 */
public class Collection extends DVD {
	
	// Adds dvd1, dvd2, dvd 3 fields to the class
	private String dvd1;
	private String dvd2;
	private String dvd3;

	
	/**
	 * Method to set the details of DVDs we entered previously
	 */

	public void setDvdDetails() {
		
		dvd1 = "Title: Indiana Jones, " + "name of the director: George Lucas and "+ "run time: 115 min";
		dvd2 = "Title: Harry Potter, "+ "name of the director: David Yates and " + "run time: 152 min";
		dvd3 = "Title:  Lord of Rings, " + "name of the director: Peter Jackson and "+ "run time: 228 min";		
		
		System.out.println("These are the others DVDs in the database");
		System.out.println(dvd1);
		System.out.println(dvd2);
		System.out.println(dvd3);
		
	}
	/**
     * Main method to create, set details for and display a DVD object
     * @param args standard Java main input arguments
     */
	public static void main(String[] args) {

		Collection newCollection = new Collection();
		
		newCollection.setAll();
		newCollection.display();
		newCollection.setDvdDetails();
		
	}

}
